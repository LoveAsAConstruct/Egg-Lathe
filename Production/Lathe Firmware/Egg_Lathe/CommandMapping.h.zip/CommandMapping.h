String CommandPrefix = "C-";
String CommandComplete = "-CC"; 
String ResponsePrefix = "R-";
String StatusPrefix = "S-";

String ConfigPrefix = "CONF";

String SetPrefix = "SET:";

String SteptypePrefix = "stept";
String SpeedPrefix = "speed";
String InputPrefix = "input";



String CalibratePrefix = "CB";

String MovementPrefix = "M";
String XString = "X";
String YString = "Y";
String WaitPrefix = "W";
String BreakwaitPrefix = "BW";
String FORCEBREAKWAIT = "FB";
